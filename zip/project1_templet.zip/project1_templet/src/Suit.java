public enum Suit {
	Hearts,
	Diamonds,
	Spades,
	Clubs
}